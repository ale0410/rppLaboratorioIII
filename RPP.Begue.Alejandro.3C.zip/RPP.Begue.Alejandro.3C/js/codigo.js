var globalTr="";
var spinner = "";
var http = new XMLHttpRequest();
var contenedorAgregar="";
var tbody;


        window.onload = function ()
        {
            
            GetAutos();
            var guardar = document.getElementById("btnGuardar");
            var agregar = document.getElementById("btnAgregar");
            spinner = document.getElementById("loader");
            var cerrar = document.getElementById("cerrar");
            cerrar.onclick=CerrarRecuadro;
            guardar.onclick=PostEditAuto;
            agregar.onclick=AbrirRecuadro;
        }

        function BoShowMessage(str)
        {
            alert(str);
        }

        function GetAutosFunction(metodo,url,funcion)
        {
            spinner.hidden=false;
            http.onreadystatechange=funcion;
            
            http.open(metodo,url,true);
            http.send();
        }

        function PostEditAutoFunction(metodo,url,funcion)
        {
            var isValid=true;
            spinner.hidden=false;
            http.open(metodo,url,true);
            http.setRequestHeader("Content-Type","application/json");
            var marca = document.getElementById("marca");
            var modelo = document.getElementById("modelo");
            var año=document.getElementById("año");
            var id = document.getElementById("id");
            if (checkValidParameters() == true){
                var data = {id:id.value,marca:marca.value,modelo:modelo.value,año:año.value};
                marca.classList.add('defaultInput');
                marca.classList.remove('error');
                modelo.classList.add('defaultInput');
                modelo.classList.remove('error');
                año.classList.add('defaultInput');
                año.classList.remove('error');
                http.onreadystatechange=RecibirPOST; 
                http.send(JSON.stringify(data));
            
            }
            else
            {
                BoShowMessage("La marca y el modelo tiene que tener 3 caracteres o mas y el año entre 2000 y 2020!!!");
                spinner.hidden=true;
            }    
        }

        function $(id)
        {
            return document.getElementById(id);
        }

        function SetAttibutes(obj, field, value)
        {
            obj.setAttribute(field, value);
        }

        function RecibirPOST()
        {
            var tabla = document.getElementById("tabla");

            if(Equals(http.readyState,4) && Equals(http.status,200))
            {
               var row = CreateElement("tr");
               var celMarca = CreateElement("td");
               celMarca.appendChild(CreateTextNode($("marca").value));
               var celModelo = CreateElement("td");
               celModelo.appendChild(CreateTextNode($("modelo").value));
               var celAnio = CreateElement("td");
               celAnio.appendChild(CreateTextNode($("año").value));

               row.appendChild(celMarca);
               row.appendChild(celModelo);
               row.appendChild(celAnio);
               //SetAttibutes($("imgLoading"),"class","imgLoadingInvisible");
               tabla.appendChild(row);
               spinner.hidden=true;
            }
        }

        function CreateElement(type)
        {
            var element = document.createElement(type);
            return element;
        }

        function CreateTextNode(str)
        {
            return document.createTextNode(str);
        }

        function Equals(val1, val2)
        {
             return val1 === val2;
        }

        function PostEditYearFunction(metodo,url,funcion)
        {
            var isValid=true;
            spinner.hidden=false;
            http.onreadystatechange=funcion;
            http.open(metodo,url,true);
            http.setRequestHeader("Content-Type","application/json");
            var año=document.getElementById("año");
            var id = document.getElementById("id");

            var data = {id:id.value,año:año.value};
                     
            http.send(JSON.stringify(data));
        }

        function checkValidParameters()
        {
            var isValid = true;
            var marca = document.getElementById("marca");
            var modelo = document.getElementById("modelo");
            var año = document.getElementById("año");
            
            if (marca.value.length < 3)
            {
                marca.classList.remove('defaultInput');
                marca.classList.add('error');
                isValid=false;
            }
            if (modelo.value.length < 3)
            {
                modelo.classList.remove('defaultInput');
                modelo.classList.add('error');
                isValid=false;
            }
            if (año.value <= 2000 || año.value >= 2020)
            {
                año.classList.remove('defaultInput');
                año.classList.add('error');
                isValid=false;
            }
            
            return isValid;
        }

        function callback()
        {
            if (http.readyState==4 && http.status==200)
            {
                armarTabla(JSON.parse(http.responseText));        
                spinner.hidden=true;  
            }
        }

        function editAuto()
        {
            if (http.readyState==4 && http.status==200)
            {
                Edit(JSON.parse(http.responseText));
                spinner.hidden=true;
            }
        }

        function editYear()
        {
            if (http.readyState==4 && http.status==200)
            {
                EditAño(JSON.parse(http.responseText));
                spinner.hidden=true;
            }
        }


        function GetAutos()
        {
            GetAutosFunction("GET","http://localhost:3000/autos",callback);
        }

        function GetAño()
        {
            PostEditYearFunction("GET","http://localhost:3000/editarYear", editYear);
        }

        function PostEditAuto()
        {
            PostEditAutoFunction("POST","http://localhost:3000/nuevoAuto",editAuto);

        }
        
        function armarTabla(jsonObj)
        {
            var tabla = document.getElementById("tabla");
           
            for(var i = 0;i<jsonObj.length;i++)
            {
                var tr = document.createElement("tr");
                var td = document.createElement("td");
                td.appendChild(document.createTextNode(jsonObj[i].make));
                tr.appendChild(td);

                var td2 = document.createElement("td");
                td2.appendChild(document.createTextNode(jsonObj[i].model));
                tr.appendChild(td2);

                var td3 = document.createElement("td");
                td3.appendChild(document.createTextNode(jsonObj[i].year));
                tr.appendChild(td3);

                //var td3 = document.createElement("SELECT"); 
                //prov.id="provincia";
                //td3.addEventListener("onchange",GetAño);

                var td4 = document.createElement("td");
                td4.appendChild(document.createTextNode(jsonObj[i].id));
                td4.hidden=true;
                tr.appendChild(td4);
                td4.hidden=true;

                //tr.addEventListener("dblclick",AbrirRecuadro);
                tabla.appendChild(tr);
            }
           
        }
        

        function AbrirRecuadro(e)
        {
            var recuadro = document.getElementById("contenedorAgregar");
            contenedorAgregar=recuadro;
            recuadro.hidden=false;
            var tr = e.target.parentNode;
            globalTr=tr;
            var marca = document.getElementById("marca");
            var modelo = document.getElementById("modelo");
            var año = document.getElementById("año");
            var id = document.getElementById("id");

            marca.value = tr.childNodes[0].innerHTML;
            modelo.value = tr.childNodes[1].innerHTML;
            año.value = tr.childNodes[2].innerHTML;
            id.value = tr.childNodes[3].innerHTML;

            marca.onclick=function(){
                checkValidParameters();
            }
           
            modelo.onclick=function(){
                checkValidParameters();
            }

            año.onclick=function(){
                checkValidParameters();
            }
                     
        }

        function Edit(res)
        {
                if (res.type=='ok')
                {
                    globalTr.childNodes[0].innerHTML = document.getElementById("marca").value;
                    globalTr.childNodes[1].innerHTML= document.getElementById("modelo").value;
                    globalTr.childNodes[2].innerHTML = document.getElementById("año").value;
                }                         
        }

        function EditAño(res)
        {
                if (res.type=='ok')
                {
                    globalTr.childNodes[2].innerHTML = document.getElementById("año").value;
                }                         
        }

        function CerrarRecuadro()
        {
            var recuadro = document.getElementById("contenedorAgregar");
            recuadro.hidden=true;
        }




        
